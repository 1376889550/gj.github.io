INSERT INTO `toolbox_plugin` (`id`, `title`, `alias`, `class`, `keyword`, `weight`, `enable`, `level`, `login`, `request_count`, `category_id`, `desc`, `create_time`, `update_time`) VALUES
(96, '����SM2����', 'guomi', 'dev\\guomi', 'guomism2,gmsm2', 0, 1, 0, 0, 19, 2, '', '2023-10-26 17:50:38', '2023-10-26 21:35:10'),
(97, '֤����Ϣ�鿴', 'cert', 'dev\\cert', 'zhengshuxinxichakan,zsxxck', 0, 1, 0, 0, 18, 2, '', '2023-10-27 16:05:08', '2023-10-27 16:05:08'),
(98, '֤���ʽת��', 'cert_convert', 'dev\\cert_convert', 'rsazhengshugeshizhuanhuan,rsazsgszh', 0, 1, 0, 0, 8, 2, '', '2023-10-24 21:25:15', '2023-10-27 16:03:56'),
(99, 'CSR������鿴', 'csr', 'dev\\csr', 'csrshengchengchakan,csrscck', 0, 1, 0, 0, 8, 2, '', '2023-11-09 20:18:19', '2023-11-10 17:14:02');
