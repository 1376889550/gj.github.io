<?php

namespace plugin\utility\imghosting;

interface api
{
    public function upload($filepath, $filename);
}