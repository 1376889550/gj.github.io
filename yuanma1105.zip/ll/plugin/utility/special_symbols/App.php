<?php
/**
 * 特殊符号大全
 */

namespace plugin\utility\special_symbols;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}