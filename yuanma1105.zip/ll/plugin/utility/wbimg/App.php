<?php
/**
 * 微博图片反查
 */

namespace plugin\utility\wbimg;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}