<?php
/**
 * 文件哈希计算
 */

namespace plugin\utility\file_hash;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}