<?php
/**
 * 字符串哈希计算
 */

namespace plugin\utility\str_hash;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}