<?php
/**
 * Unix时间戳转换
 */

namespace plugin\utility\timestamp;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}