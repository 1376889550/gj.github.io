<?php

namespace plugin\utility\short_url;

interface api
{
    public function create($url);
}