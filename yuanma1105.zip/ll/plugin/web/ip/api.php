<?php

namespace plugin\web\ip;

interface api
{
    public function query($ip);
}