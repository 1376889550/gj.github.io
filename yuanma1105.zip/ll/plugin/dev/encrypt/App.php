<?php
/**
 * 对称加密解密
 */

namespace plugin\dev\encrypt;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}