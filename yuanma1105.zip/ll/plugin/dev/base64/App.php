<?php
/**
 * base64编码/解码
 */

namespace plugin\dev\base64;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}