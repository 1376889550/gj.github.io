<?php
/**
 * MimeType类型速查
 */

namespace plugin\dev\mime_type;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}