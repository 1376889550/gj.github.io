<?php
/**
 * Html 格式化/加密/压缩
 */

namespace plugin\dev\code_html;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}