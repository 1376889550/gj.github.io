<?php
/**
 * JavaScript 格式化/混淆/压缩
 */

namespace plugin\dev\code_js;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}