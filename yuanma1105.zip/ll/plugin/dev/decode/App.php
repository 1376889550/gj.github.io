<?php
/**
 * 编码解码器
 */

namespace plugin\dev\decode;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}