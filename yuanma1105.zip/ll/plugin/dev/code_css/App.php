<?php
/**
 * CSS 格式化/压缩
 */

namespace plugin\dev\code_css;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}