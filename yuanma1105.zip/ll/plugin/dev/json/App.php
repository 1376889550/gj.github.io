<?php
/**
 * JSON解析格式化
 */

namespace plugin\dev\json;

use app\Plugin;

class App extends Plugin
{

    public function index()
    {
        return $this->view();
    }
}