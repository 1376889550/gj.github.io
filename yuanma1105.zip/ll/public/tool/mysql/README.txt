/********************
*                   *
*     ionutvmi      *
*  wap phpmyadmin   *
*     v 2.0.3       *
*                   *
********************/

/*** REQUIREMENTS **/
You need a database already created so you can use this.


/****** INSTALL ****/
1. unzip wap_phpmyadmin_2_0_3.zip file
2. chmod data folder 777
3. ENJOY AND USE IT


/******* bugs ******/
I'M STILL TESTING THIS SCRIPT SO IF YOU FIND ANY BUGS PLEASE REPORT IT AT ionutvmi@gmail.com


Thank you,
ionutvmi