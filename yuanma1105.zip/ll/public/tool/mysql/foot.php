<?php
echo "<div class='footer'>&#169;ionutvmi | ".$lang["Check_for_updates"]." | 7-Jan-2012</div>

</body></html>";
?>